// =============================================
// MAIN JS - SIKAD UN PGRI Kediri
// =============================================

document.addEventListener('DOMContentLoaded', function () {

    // Mobile hamburger menu toggle
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('navLinks');

    if (hamburger && navLinks) {
        hamburger.addEventListener('click', function () {
            navLinks.classList.toggle('open');
        });
    }

    // Auto-hide alert messages after 4 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.4s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 400);
        }, 4000);
    });

    // File input preview name (Form Upload Tugas)
    const fileInput = document.getElementById('file_tugas');
    const fileLabel = document.getElementById('fileLabel');
    if (fileInput && fileLabel) {
        fileInput.addEventListener('change', function () {
            if (this.files && this.files.length > 0) {
                fileLabel.textContent = '📎 ' + this.files[0].name;
            } else {
                fileLabel.textContent = 'Belum ada file dipilih';
            }
        });
    }

    // Simple client-side table search (Gallery / Tabel Tugas)
    const searchInput = document.getElementById('tableSearch');
    const table = document.getElementById('dataTable');
    if (searchInput && table) {
        searchInput.addEventListener('keyup', function () {
            const query = this.value.toLowerCase();
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(function (row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(query) ? '' : 'none';
            });
        });
    }

    // Filter mata kuliah pada tabel
    const filterMK = document.getElementById('filterMK');
    if (filterMK && table) {
        filterMK.addEventListener('change', function () {
            const val = this.value;
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(function (row) {
                if (val === 'semua') {
                    row.style.display = '';
                } else {
                    row.style.display = row.getAttribute('data-mk') === val ? '' : 'none';
                }
            });
        });
    }

});
